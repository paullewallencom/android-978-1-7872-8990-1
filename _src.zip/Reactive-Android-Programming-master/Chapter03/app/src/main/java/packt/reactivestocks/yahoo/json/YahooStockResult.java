package packt.reactivestocks.yahoo.json;

public class YahooStockResult {
    private YahooStockQuery query;

    public YahooStockQuery getQuery() {
        return query;
    }
}
